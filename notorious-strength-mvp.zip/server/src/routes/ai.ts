import { Router } from 'express';
import { analyzeLiftVideo, chatReply } from '../services/aiOrchestrator.js';

export const aiRouter = Router();

// POST /ai/form-check  { lift, videoUri }
// In production `videoUri` should already be a signed URL to the file in
// Cloudflare R2 (uploaded by the client directly via a pre-signed PUT URL,
// not proxied through this server) — see the blueprint's storage layer note.
aiRouter.post('/form-check', async (req, res) => {
  const { lift, videoUri } = req.body ?? {};
  if (!lift || !videoUri) return res.status(400).json({ error: 'lift and videoUri are required' });

  try {
    const analysis = await analyzeLiftVideo({ lift, videoUrl: videoUri });
    res.json({
      id: `fc_${Date.now()}`,
      lift,
      createdAt: new Date().toISOString(),
      aiProvider: 'gemini-2.5-flash',
      status: 'complete',
      ...analysis,
    });
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// POST /ai/chat  { history, message, complex? }
aiRouter.post('/chat', async (req, res) => {
  const { history = [], message, complex } = req.body ?? {};
  if (!message) return res.status(400).json({ error: 'message is required' });

  try {
    const reply = await chatReply({ history, message, complex });
    res.json({ id: `msg_${Date.now()}`, role: 'assistant', text: reply.text, provider: reply.provider });
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});
