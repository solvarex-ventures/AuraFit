import { Router } from 'express';
import { createOrder, verifyWebhookSignature } from '../services/razorpay.js';

export const paymentsRouter = Router();

// POST /payments/orders  { itemId, itemLabel, amountInr, kind }
paymentsRouter.post('/orders', async (req, res) => {
  const { itemId, amountInr } = req.body ?? {};
  if (!itemId || !amountInr) return res.status(400).json({ error: 'itemId and amountInr are required' });

  try {
    const order = await createOrder({ amountInr, receipt: `${itemId}_${Date.now()}` });
    res.json(order);
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// POST /payments/webhook — configure this URL in the Razorpay dashboard.
// Verifies the signature before unlocking an ebook / activating a coaching
// subscription, so a spoofed request can never grant access for free.
paymentsRouter.post('/webhook', (req, res) => {
  const signature = req.header('x-razorpay-signature') ?? '';
  const rawBody = JSON.stringify(req.body);

  try {
    if (!verifyWebhookSignature(rawBody, signature)) {
      return res.status(400).json({ error: 'Invalid signature' });
    }
    // TODO: look up the order in your database and mark the purchase/
    // subscription active. Kept out of this scaffold since it depends on
    // your chosen ORM/schema.
    res.json({ received: true });
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});
