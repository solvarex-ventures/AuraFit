import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import { aiRouter } from './routes/ai.js';
import { paymentsRouter } from './routes/payments.js';

const app = express();
app.use(cors({ origin: process.env.CLIENT_ORIGIN ?? '*' }));
app.use(express.json());

app.get('/health', (_req, res) => res.json({ status: 'ok', service: 'notorious-strength-server' }));
app.use('/ai', aiRouter);
app.use('/payments', paymentsRouter);

const port = Number(process.env.PORT ?? 4000);
app.listen(port, () => {
  console.log(`Notorious Strength API listening on :${port}`);
  if (!process.env.GEMINI_API_KEY && !process.env.OPENAI_API_KEY) {
    console.warn('No AI keys set — /ai routes will error until GEMINI_API_KEY or OPENAI_API_KEY is set in .env');
  }
  if (!process.env.RAZORPAY_KEY_ID) {
    console.warn('No Razorpay keys set — /payments/orders will error until RAZORPAY_KEY_ID/SECRET are set in .env');
  }
});
