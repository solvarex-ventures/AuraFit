import React from 'react';
import { NavigationContainer, DefaultTheme } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { useAuth } from '@/context/AuthContext';
import { colors } from '@/theme';

import RoleSelectScreen from '@/screens/auth/RoleSelectScreen';
import ClientHomeScreen from '@/screens/client/ClientHomeScreen';
import EbookStoreScreen from '@/screens/client/EbookStoreScreen';
import CoachingScreen from '@/screens/client/CoachingScreen';
import BookConsultationScreen from '@/screens/client/BookConsultationScreen';
import FormCheckScreen from '@/screens/client/FormCheckScreen';
import AIChatScreen from '@/screens/client/AIChatScreen';
import ProfileScreen from '@/screens/client/ProfileScreen';
import TrainerDashboardScreen from '@/screens/trainer/TrainerDashboardScreen';
import ClientListScreen from '@/screens/trainer/ClientListScreen';
import EarningsScreen from '@/screens/trainer/EarningsScreen';

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

const navTheme = {
  ...DefaultTheme,
  colors: {
    ...DefaultTheme.colors,
    background: colors.bg,
    card: colors.surface,
    text: colors.ink,
    border: colors.border,
    primary: colors.accent,
  },
};

function ClientTabs() {
  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,
        tabBarStyle: { backgroundColor: colors.surface, borderTopColor: colors.border },
        tabBarActiveTintColor: colors.accent,
        tabBarInactiveTintColor: colors.inkMuted,
      }}
    >
      <Tab.Screen name="Home" component={ClientHomeScreen} />
      <Tab.Screen name="Form Check" component={FormCheckScreen} />
      <Tab.Screen name="AI Coach" component={AIChatScreen} />
      <Tab.Screen name="Ebooks" component={EbookStoreScreen} />
      <Tab.Screen name="Coaching" component={CoachingScreen} />
      <Tab.Screen name="Book" component={BookConsultationScreen} />
      <Tab.Screen name="Profile" component={ProfileScreen} />
    </Tab.Navigator>
  );
}

function TrainerTabs() {
  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,
        tabBarStyle: { backgroundColor: colors.surface, borderTopColor: colors.border },
        tabBarActiveTintColor: colors.accent,
        tabBarInactiveTintColor: colors.inkMuted,
      }}
    >
      <Tab.Screen name="Dashboard" component={TrainerDashboardScreen} />
      <Tab.Screen name="Clients" component={ClientListScreen} />
      <Tab.Screen name="Earnings" component={EarningsScreen} />
      <Tab.Screen name="Profile" component={ProfileScreen} />
    </Tab.Navigator>
  );
}

export default function RootNavigator() {
  const { user } = useAuth();

  return (
    <NavigationContainer theme={navTheme}>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        {!user ? (
          <Stack.Screen name="RoleSelect" component={RoleSelectScreen} />
        ) : user.role === 'client' ? (
          <Stack.Screen name="ClientTabs" component={ClientTabs} />
        ) : (
          <Stack.Screen name="TrainerTabs" component={TrainerTabs} />
        )}
      </Stack.Navigator>
    </NavigationContainer>
  );
}
