// AI orchestration layer — this is the ONE place the app talks to AI.
// Screens never call Gemini/OpenAI directly; they call these functions.
// Today every function returns a realistic MOCK response so the app is
// fully demoable with zero API keys. To go live:
//
//   1. Deploy the /server package (see server/README) with your
//      GEMINI_API_KEY and OPENAI_API_KEY set.
//   2. Set EXPO_PUBLIC_API_BASE_URL in app/.env to that server's URL.
//   3. Flip USE_MOCK to false below.
//
// The server-side src/services/aiOrchestrator.ts contains the real
// Gemini/OpenAI calls and the routing rules described in the blueprint
// (Gemini 2.5 Flash for video form-check, cheapest model for chat,
// GPT-5/Gemini Pro reserved for complex programming questions).

import { ChatMessage, FormCheckFault, FormCheckResult } from '@/types';
import { EXERCISE_FAULT_LIBRARY } from '@/data/mockData';
import { apiBaseUrl } from '@/services/api';

const USE_MOCK = true;

function mockFaultsFor(lift: string): FormCheckFault[] {
  const library = EXERCISE_FAULT_LIBRARY[lift] ?? EXERCISE_FAULT_LIBRARY.Squat;
  return [
    {
      timestampSec: 2,
      label: library[0],
      detail: `At the 0:02 mark the model flags ${library[0].toLowerCase()} — worth filming from a second angle to confirm.`,
      severity: 'warning',
    },
    {
      timestampSec: 5,
      label: library[Math.min(1, library.length - 1)],
      detail: `Mid-rep, ${library[Math.min(1, library.length - 1)].toLowerCase()} is visible. This is the most common fault on this lift in the exercise library.`,
      severity: 'info',
    },
  ];
}

export async function requestFormCheck(params: {
  lift: string;
  videoUri: string;
}): Promise<FormCheckResult> {
  if (USE_MOCK) {
    await delay(1200);
    return {
      id: `fc_${Date.now()}`,
      lift: params.lift,
      createdAt: new Date().toISOString(),
      aiProvider: 'gemini-2.5-flash',
      status: 'complete',
      overallNote:
        'MOCK RESULT — wire up server/src/services/aiOrchestrator.ts with a real Gemini key to replace this with an actual multimodal analysis of the uploaded video.',
      faults: mockFaultsFor(params.lift),
    };
  }

  const res = await fetch(`${apiBaseUrl()}/ai/form-check`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });
  if (!res.ok) throw new Error('Form-check request failed');
  return res.json();
}

export async function sendChatMessage(params: {
  history: ChatMessage[];
  message: string;
}): Promise<ChatMessage> {
  if (USE_MOCK) {
    await delay(700);
    return {
      id: `msg_${Date.now()}`,
      role: 'assistant',
      provider: 'gemini',
      text: mockAssistantReply(params.message),
    };
  }

  const res = await fetch(`${apiBaseUrl()}/ai/chat`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });
  if (!res.ok) throw new Error('Chat request failed');
  return res.json();
}

function mockAssistantReply(message: string): string {
  const lower = message.toLowerCase();
  if (lower.includes('protein') || lower.includes('macro')) {
    return 'MOCK — In production this routes to Gemini 2.5 Flash-Lite / GPT-4o mini for fast macro Q&A, grounded in your active diet plan. Roughly: 1.6–2.2g protein per kg bodyweight is a solid starting target for a lean bulk.';
  }
  if (lower.includes('deload')) {
    return "MOCK — Deloads are scheduled every 4th mesocycle week in your program by default: cut volume ~40% and intensity ~10-20%, keep movement patterns the same.";
  }
  return `MOCK ASSISTANT REPLY for "${message}". Connect server/src/services/aiOrchestrator.ts to a real Gemini/OpenAI key to replace this.`;
}

function delay(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
