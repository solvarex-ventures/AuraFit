// Small helper so every service reads the backend URL from one place.
// Set EXPO_PUBLIC_API_BASE_URL in app/.env once the /server package is deployed.
export function apiBaseUrl(): string {
  return process.env.EXPO_PUBLIC_API_BASE_URL ?? 'http://localhost:4000';
}
