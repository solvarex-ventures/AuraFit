// Payment layer — mirrors the fee structure in the blueprint (Razorpay,
// 2% + GST on cards/UPI/netbanking, ~1% extra on subscriptions).
// USE_MOCK=true simulates a successful Razorpay checkout instantly so the
// full purchase flow (ebook, coaching, subscription) is demoable without a
// merchant account. To go live: complete Razorpay KYC, set
// RAZORPAY_KEY_ID / RAZORPAY_KEY_SECRET on the server, and flip USE_MOCK.

import { apiBaseUrl } from '@/services/api';

const USE_MOCK = true;

export interface CheckoutParams {
  itemId: string;
  itemLabel: string;
  amountInr: number;
  kind: 'ebook' | 'subscription' | 'coaching' | 'consultation';
}

export interface CheckoutResult {
  success: boolean;
  orderId: string;
  paymentId: string;
}

export async function startCheckout(params: CheckoutParams): Promise<CheckoutResult> {
  if (USE_MOCK) {
    await new Promise((r) => setTimeout(r, 900));
    return {
      success: true,
      orderId: `order_mock_${Date.now()}`,
      paymentId: `pay_mock_${Date.now()}`,
    };
  }

  // Real flow: ask our server to create a Razorpay Order, then open the
  // Razorpay Checkout SDK with that order id. See server/src/routes/payments.ts.
  const orderRes = await fetch(`${apiBaseUrl()}/payments/orders`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });
  if (!orderRes.ok) throw new Error('Could not create order');
  const order = await orderRes.json();

  // In a real build, hand `order.id` to react-native-razorpay here and
  // await the user completing checkout in the native Razorpay sheet.
  throw new Error(
    'Live checkout not wired yet — install react-native-razorpay and open it with the order returned above.'
  );
}
