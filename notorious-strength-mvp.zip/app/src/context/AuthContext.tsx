import React, { createContext, useContext, useMemo, useState } from 'react';
import { Role, User } from '@/types';

interface AuthContextValue {
  user: User | null;
  signIn: (name: string, role: Role) => void;
  signOut: () => void;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);

  const value = useMemo<AuthContextValue>(
    () => ({
      user,
      signIn: (name, role) =>
        setUser({
          id: `user_${Date.now()}`,
          name,
          role,
          email: `${name.toLowerCase().replace(/\s+/g, '.')}@example.com`,
        }),
      signOut: () => setUser(null),
    }),
    [user]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
