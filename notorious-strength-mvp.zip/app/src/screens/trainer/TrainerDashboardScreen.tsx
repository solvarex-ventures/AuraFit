import React from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Card } from '@/components/Card';
import { ScreenHeader } from '@/components/ScreenHeader';
import { useAuth } from '@/context/AuthContext';
import { colors, spacing } from '@/theme';

export default function TrainerDashboardScreen() {
  const { user } = useAuth();

  return (
    <SafeAreaView style={styles.screen} edges={['top']}>
      <ScrollView contentContainerStyle={styles.content}>
        <ScreenHeader title={`Coach console — ${user?.name}`} subtitle="Client load, pending reviews, and this month's payout." />

        <View style={styles.statRow}>
          <Stat label="Active clients" value="5 / 5" />
          <Stat label="Form-checks to review" value="3" />
          <Stat label="Avg. rating" value="5.0" />
        </View>

        <Text style={styles.sectionTitle}>Flagged for your review</Text>
        <Card style={styles.reviewCard}>
          <Text style={styles.reviewLift}>Squat — Rohit K.</Text>
          <Text style={styles.reviewNote}>AI flagged knee valgus at 0:02 with medium confidence — marked for coach confirmation.</Text>
        </Card>
        <Card style={styles.reviewCard}>
          <Text style={styles.reviewLift}>Deadlift — Priya S.</Text>
          <Text style={styles.reviewNote}>Client marked "not sure about this" on their own upload — escalated automatically.</Text>
        </Card>
      </ScrollView>
    </SafeAreaView>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <Card style={styles.stat}>
      <Text style={styles.statValue}>{value}</Text>
      <Text style={styles.statLabel}>{label}</Text>
    </Card>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.bg },
  content: { paddingHorizontal: spacing(5), paddingBottom: spacing(10), gap: spacing(4) },
  statRow: { flexDirection: 'row', gap: spacing(3) },
  stat: { flex: 1, alignItems: 'center', paddingVertical: spacing(4) },
  statValue: { color: colors.ink, fontSize: 20, fontWeight: '800' },
  statLabel: { color: colors.inkMuted, fontSize: 11, marginTop: 4, textAlign: 'center' },
  sectionTitle: { color: colors.ink, fontSize: 14, fontWeight: '700' },
  reviewCard: { gap: 4 },
  reviewLift: { color: colors.ink, fontSize: 14, fontWeight: '700' },
  reviewNote: { color: colors.inkMuted, fontSize: 12.5, lineHeight: 17 },
});
