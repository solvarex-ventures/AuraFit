import React, { useState } from 'react';
import { StyleSheet, Text, TextInput, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Button } from '@/components/Button';
import { useAuth } from '@/context/AuthContext';
import { colors, spacing } from '@/theme';
import { Role } from '@/types';

export default function RoleSelectScreen() {
  const { signIn } = useAuth();
  const [name, setName] = useState('');
  const [role, setRole] = useState<Role>('client');

  return (
    <SafeAreaView style={styles.screen}>
      <View style={styles.content}>
        <Text style={styles.eyebrow}>NOTORIOUS STRENGTH</Text>
        <Text style={styles.title}>Train like it's personal.</Text>
        <Text style={styles.subtitle}>
          Sign in to the demo as a client or as a trainer to see both sides of the platform.
        </Text>

        <TextInput
          style={styles.input}
          placeholder="Your name"
          placeholderTextColor={colors.inkMuted}
          value={name}
          onChangeText={setName}
        />

        <View style={styles.roleRow}>
          <RolePill label="I'm a Client" active={role === 'client'} onPress={() => setRole('client')} />
          <RolePill label="I'm a Trainer" active={role === 'trainer'} onPress={() => setRole('trainer')} />
        </View>

        <Button
          label="Enter demo"
          onPress={() => signIn(name.trim() || (role === 'client' ? 'Demo Client' : 'Demo Trainer'), role)}
        />
      </View>
    </SafeAreaView>
  );
}

function RolePill({ label, active, onPress }: { label: string; active: boolean; onPress: () => void }) {
  return (
    <Text
      onPress={onPress}
      style={[styles.pill, active && styles.pillActive]}
    >
      {label}
    </Text>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.bg },
  content: { flex: 1, justifyContent: 'center', paddingHorizontal: spacing(6) },
  eyebrow: { color: colors.accent, fontSize: 12, fontWeight: '700', letterSpacing: 2, marginBottom: spacing(2) },
  title: { color: colors.ink, fontSize: 32, fontWeight: '800', marginBottom: spacing(2) },
  subtitle: { color: colors.inkMuted, fontSize: 14, marginBottom: spacing(6), lineHeight: 20 },
  input: {
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 10,
    paddingHorizontal: spacing(4),
    paddingVertical: spacing(3),
    color: colors.ink,
    marginBottom: spacing(4),
    fontSize: 15,
  },
  roleRow: { flexDirection: 'row', gap: spacing(2), marginBottom: spacing(6) },
  pill: {
    flex: 1,
    textAlign: 'center',
    paddingVertical: spacing(3),
    borderRadius: 999,
    borderWidth: 1,
    borderColor: colors.border,
    color: colors.inkMuted,
    fontSize: 13,
    fontWeight: '700',
    overflow: 'hidden',
  },
  pillActive: {
    backgroundColor: colors.accent,
    borderColor: colors.accent,
    color: colors.accentInk,
  },
});
