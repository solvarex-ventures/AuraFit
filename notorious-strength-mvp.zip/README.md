# Notorious Strength — MVP

This package is the code half of the [Notorious Strength Blueprint](../blueprint.html) — the
business strategy document. It's a working, verified-to-build MVP: a cross-platform
(Android + web, iOS-ready) client/trainer app plus a backend that wires up real Gemini,
OpenAI and Razorpay integrations once you have accounts for them.

Everything runs **fully mocked out of the box** — no API keys needed to try it.

## What's inside

```
notorious-strength/
  blueprint.html        the business strategy report (open in a browser)
  app/                   the Expo (React Native) client — Android, iOS, and web from one codebase
  server/                the Node/Express backend — real AI + payments integration
```

## Quick start — the app (mocked, no keys needed)

```bash
cd app
npm install
npm run web        # opens in your browser — fastest way to look around
# or
npm start          # scan the QR code with Expo Go on your Android phone
```

You'll land on a role picker — try both "I'm a Client" (ebook store, coaching tiers,
AI form-check video upload, AI chat, booking) and "I'm a Trainer" (client list, flagged
form-checks, earnings) to see both sides of the marketplace. This build was verified to
install and bundle cleanly (`npx expo export --platform web`, 443 modules, no errors).

Every screen currently talks to `app/src/services/aiService.ts` and
`app/src/services/paymentService.ts`, which return realistic mock data. That's
deliberate — it's what makes the app fully demoable before you have any accounts set up.

## Going live: connect the real backend

1. **Deploy the server** (see `server/README` below) with your own Gemini, OpenAI and
   Razorpay keys.
2. In `app/`, copy `.env.example` to `.env` and set `EXPO_PUBLIC_API_BASE_URL` to your
   deployed server's URL.
3. In `app/src/services/aiService.ts` and `app/src/services/paymentService.ts`, flip
   `USE_MOCK` to `false`. The real request code is already written — it's commented
   with exactly what it does.
4. For live Razorpay checkout inside the app, add `react-native-razorpay` and open it
   with the order returned from `POST /payments/orders` (there's a `TODO`-style comment
   marking exactly where in `paymentService.ts`).

## Getting the accounts you need

| Account | Where | Notes |
|---|---|---|
| Razorpay | dashboard.razorpay.com | Complete business KYC first (PAN, bank account, business proof) — typically 2–5 working days. Use a payment *link* for pre-launch ebook/coaching sales while the full merchant account activates. |
| Gemini API key | aistudio.google.com/app/apikey | Powers the AI form-check (multimodal video analysis) and fast chat. |
| OpenAI API key | platform.openai.com/api-keys | Used as the alternate/fallback chat provider. |

## Server

```bash
cd server
npm install
cp .env.example .env     # fill in GEMINI_API_KEY / OPENAI_API_KEY / RAZORPAY_KEY_ID / RAZORPAY_KEY_SECRET
npm run dev               # starts on :4000, typechecked clean with `npx tsc --noEmit`
```

Routes:
- `POST /ai/form-check` — send `{ lift, videoUri }`, get back timestamped fault analysis from Gemini 2.5 Flash.
- `POST /ai/chat` — send `{ history, message, complex? }`, routed to the cheapest capable model unless `complex: true`.
- `POST /payments/orders` — creates a real Razorpay order.
- `POST /payments/webhook` — point your Razorpay dashboard's webhook here; signature-verified before unlocking a purchase.

The routing strategy (which model handles which task, and why) is documented inline in
`server/src/services/aiOrchestrator.ts` and matches the blueprint's AI section exactly.

## Building the real Android app (Play Store)

```bash
cd app
npm install -g eas-cli
eas login
eas build:configure
eas build --platform android
```

This produces a signed AAB you can upload to the Play Console. Complete the Data Safety
form accurately before submission — health/fitness apps get extra review scrutiny on it
(see the blueprint's Risk Register).

## What's mocked vs. real right now

| Feature | Status |
|---|---|
| Client/trainer role flows, navigation, all screens | Real, fully built |
| Ebook store, coaching tiers, pricing | Real UI, pulling from `src/data/mockData.ts` — the single source of truth for pricing, matches the blueprint's fee structure exactly |
| AI form-check video upload | Real upload (device video picker) → **mocked** analysis response |
| AI chat | Real UI → **mocked** replies |
| Checkout (ebook/coaching/consultation) | **Mocked** instant-success — swap in Razorpay per steps above |
| Server AI orchestration (Gemini/OpenAI) | Real code, needs your API keys to run |
| Server payments (Razorpay orders + webhook) | Real code, needs your Razorpay keys to run |
| Database / persistence | **Not included** — this scaffold has no database yet. Recommended: Supabase (Postgres), as specified in the blueprint's tech architecture, with row-level security mapped to client/trainer/admin roles. |
| Auth | Mocked (name + role only) — swap for Supabase Auth or similar before going live |

## Next build priorities, in order

1. Add Supabase (or your preferred Postgres host) for real user accounts, purchases and coaching-session records.
2. Wire `react-native-razorpay` for live checkout.
3. Move video upload from the local device picker to a direct pre-signed upload into Cloudflare R2, and pass that signed URL (not the raw file) to `/ai/form-check`.
4. Add the coach-review queue backing the "Flagged for your review" cards on the trainer dashboard.
